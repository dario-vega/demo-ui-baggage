define(function() {
  'use strict';

  return {
  "take_photo" : {
    "camera" : "Camera",
    "browse" : "Browse",
    "cancel" : "Cancel"
  }
};
});