define(function() {
  'use strict';

  return {
  "add_to_home_screen_header" : "Add to Home Screen",
  "add_to_home_screen" : "Application is available for install. Would you like to add it to home screen?",
  "add_to_home_screen_cancel" : "Cancel",
  "add_to_home_screen_confirm" : "Add"
};
});