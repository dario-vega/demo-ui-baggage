define(function() {
  'use strict';

  return {
  "shell_title_navigation_drawer" : "Application Navigation Drawer",
  "shell_logo_tooltip" : "Application Logo",
  "shell_header_title" : "Blue Mist Airways",
  "shell_footer_about_link" : "About",
  "shell_footer_copyright" : "Created with Visual Builder, Copyright © 2019",
  "shell_title_tooltip" : "Application Name",
  "shell_sign_out" : "Sign Out"
};
});